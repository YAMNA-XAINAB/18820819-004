package com.uog.employee.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.util.JSONPObject;
import com.uog.employee.model.Employee;
import com.uog.employee.repository.employeeRepository;

@RestController
@RequestMapping("/api/students")
public class employeeController {
	
	@Autowired
	private employeeRepository employeerepository;
	
	@GetMapping("")
	private List<STUDENT> getAllStudents() {
		return employeerepository.findAll();
	}
	
	@GetMapping("/{id}")
	private STUDENT getStudent(@PathVariable Long id) {
		return employeerepository.findOne(id);
	}
	
	@GetMapping("/name/{name}")
	private STUDENT getStudentbyRoll(@PathVariable String name) {
		return employeerepository.findbyName(name);
	}
	
	@PostMapping("")
	private STUDENT addStudent(@RequestBody STUDENT employee) {		
		return employeerepository.save(employee);
	}
	
	@DeleteMapping("/{id}")
	private String deletStudent(@PathVariable Long id) {
		//employeerepository.deleteById(id);
		employeerepository.delete(id);
		return "Deleted";	
	}
	
	@PutMapping("/{id}") 
	private Employee putStudent(@RequestBody STUDENT newStudent, @PathVariable Long id) {
		if (newEmployee != null) {

			  employeerepository.findOne(id).setSTUDENT_NAME(newStudent.getSTUDENT_NAME());
			  employeerepository.findOne(id).setSTUDENT_ROLL(newStudent.getSTUDENT_ROLL());
			  employeerepository.findOne(id).setSTUDENT_TASK(newStudent.getSTUDENT_TASK());
			  employeerepository.findOne(id).setISACTIVE(newStudent.getISACTIVE());
		  }
		  return employeerepository.findOne(id);
		  
	  }
	  @GetMapping("/active")
		private List<STUDENT> getActive() {
			return employeerepository.findActive();
		}
}

