package com.uog.employee.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.uog.employee.model.Employee;

public interface employeeRepository extends JpaRepository<STUDENT, Long>{
	@Query(value="select * from TBLSTUDENT where ISACTIVE='Y'", nativeQuery = true)
	List<STUDENT> findActive();
	
	@Query(value="select * from TBLSTUDENT where STUDENT_ROLL=:name", nativeQuery = true)
	STUDENT findbyName(@Param("name") String studentName);
}
