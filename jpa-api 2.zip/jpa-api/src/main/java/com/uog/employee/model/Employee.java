package com.uog.employee.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TBLSTUDENT")

public class STUDENT {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long STUDENT_ID;
	
	@Column(name = "STUDENT_NAME")
	private String STUDENT_NAME;
		@Column(name = "STUDENT_ROLL")
	private String STUDENT_ROLL;
	
	@Column(name = "STUDENT_TASK")
	private String STUDENT_TASK;

	@Column(name = "ISACTIVE")
	private char ISACTIVE;
	
	
	public Long getSTUDENT_ID() {
		return STUDENT_ID;
	}

	public void setSTUDENT_ID(Long eMPLOYEE_ID) {
		STUDENT_ID = eMPLOYEE_ID;
	}

	public String getSTUDENT_NAME() {
		return STUDENT_NAME;
	}

	public void setSTUDENT_NAME(String eMPLOYEE_NAME) {
		STUDENT_NAME = eMPLOYEE_NAME;
	}
		public String getSTUDENT_ROLL() {
		return STUDENT_ROLL;
	}

	public void setSTUDENT_ROLL(String sTudent_ROLL) {
		STUDENT_ROLL = sTudent_ROLL;
	}

	public int getSTUDENT_TASK() {
		return STUDENT_TASK;
	}

	public void setSTUDENT_TASK(int STUDENT_TASK) {
		STUDENT_TASK = STUDENT_TASK;
	}

	public char getISACTIVE() {
		return ISACTIVE;
	}

	public void setISACTIVE(char iSACTIVE) {
		ISACTIVE = iSACTIVE;
	}
		
}

















